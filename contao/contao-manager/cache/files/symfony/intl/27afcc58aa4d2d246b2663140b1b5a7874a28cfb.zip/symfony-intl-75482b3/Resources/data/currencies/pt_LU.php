<?php

return [
    'Names' => [
        'LUF' => [
            'F',
            'Franco luxemburguês',
        ],
    ],
];
