<?php

return [
    'Names' => [
        'GBP' => [
            'GB£',
            'British Pound',
        ],
        'SHP' => [
            '£',
            'St Helena Pound',
        ],
    ],
];
