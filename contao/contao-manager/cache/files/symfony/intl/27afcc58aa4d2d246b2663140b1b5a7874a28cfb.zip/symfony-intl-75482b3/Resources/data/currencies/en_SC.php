<?php

return [
    'Names' => [
        'SCR' => [
            'SR',
            'Seychellois Rupee',
        ],
    ],
];
