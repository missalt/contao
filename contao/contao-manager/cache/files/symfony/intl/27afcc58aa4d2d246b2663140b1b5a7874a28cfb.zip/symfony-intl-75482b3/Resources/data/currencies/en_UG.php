<?php

return [
    'Names' => [
        'UGX' => [
            'USh',
            'Ugandan Shilling',
        ],
    ],
];
