<?php

return [
    'Names' => [
        'KMF' => [
            'CF',
            'franc comorien',
        ],
    ],
];
