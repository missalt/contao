<?php

return [
    'Names' => [
        'GNF' => [
            'GNF',
            '𞤊𞤢𞤪𞤢𞤲 𞤘𞤭𞤲𞤫𞤲𞤳𞤮',
        ],
    ],
];
