<?php

return [
    'Names' => [
        'CRC' => [
            'CRC',
            'Costa Rican colon',
        ],
        'ISK' => [
            'ISK',
            'Icelandic krona',
        ],
        'NIO' => [
            'NIO',
            'Nicaraguan cordoba',
        ],
        'RUB' => [
            'RUB',
            'Russian ruble',
        ],
        'STN' => [
            'STN',
            'Sao Tome & Principe Dobra',
        ],
        'VES' => [
            'VES',
            'Venezuelan bolivar',
        ],
    ],
];
