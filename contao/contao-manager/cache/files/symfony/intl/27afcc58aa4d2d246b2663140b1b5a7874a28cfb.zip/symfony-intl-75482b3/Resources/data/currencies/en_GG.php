<?php

return [
    'Names' => [
        'GBP' => [
            '£',
            'UK Pound',
        ],
    ],
];
